package com.library;

public interface library {
    void read();
}
