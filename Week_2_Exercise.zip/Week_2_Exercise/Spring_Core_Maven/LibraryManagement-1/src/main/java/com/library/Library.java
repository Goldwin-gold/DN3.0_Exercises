package com.library;

public interface Library {
	void read();
}
