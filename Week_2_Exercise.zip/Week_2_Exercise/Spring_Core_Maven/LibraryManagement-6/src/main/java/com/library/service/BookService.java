package com.library.service;

import org.springframework.stereotype.Service;

import com.library.Repository.BookRepository;
@Service
public class BookService {
	BookRepository head;
	BookRepository tail;
	int length=0;
	
	private BookRepository[] book;
	
	public BookService() {
		book=new BookRepository[100];
	}
	
	public void add(BookRepository books) {
		if(length==0) {
			head=books;
			tail=books;
			length=1;
		}else {
			tail.next=books;
			tail=books;
		}
	}
	
	public void print() {
		BookRepository temp=head;
		while(temp!=null) {
			System.out.println(temp);
			temp=temp.next;
		}
	}

}
