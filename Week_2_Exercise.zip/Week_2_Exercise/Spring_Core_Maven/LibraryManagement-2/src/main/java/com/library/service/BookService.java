package com.library.service;

import com.library.Book;
import com.library.repositoy.BookRepository;

public class BookService {
	 private BookRepository bookRepository;

	    
	    public void setBookRepository(BookRepository bookRepository) {
	        this.bookRepository = bookRepository;
	    }

	    
	    public void addBook(Book book) {
	        bookRepository.save(book);
	    }

}
