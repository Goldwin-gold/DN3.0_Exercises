package com.library.aspect;


public class LoggingAspect {
	public void loggingBefore() {
		System.out.println("Before Logging ");
	}
	
	public void loggingAfter() {
		System.out.println("After logging");
	}
}
